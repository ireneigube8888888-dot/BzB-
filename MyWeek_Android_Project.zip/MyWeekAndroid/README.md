# My Week Android app

This is an Android WebView wrapper for the My Week personal productivity dashboard.
The dashboard HTML is bundled locally in `app/src/main/assets/index.html`; the app does not need a network connection to display it.

## Build an APK in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions
Push this project to a GitHub repository, then open **Actions > Build My Week APK > Run workflow**.
When complete, download the `my-week-debug-apk` artifact from the workflow run.

## Notes
- App name: My Week
- Package: `com.example.myweek`
- Minimum Android: Android 6.0 (API 23)
- Dashboard data uses browser local storage within the app's WebView. Clearing app storage can erase saved dashboard entries, so use the dashboard's Export feature for backups.
- This is a debug APK workflow. A release APK should be signed with your own private signing key before distribution.
